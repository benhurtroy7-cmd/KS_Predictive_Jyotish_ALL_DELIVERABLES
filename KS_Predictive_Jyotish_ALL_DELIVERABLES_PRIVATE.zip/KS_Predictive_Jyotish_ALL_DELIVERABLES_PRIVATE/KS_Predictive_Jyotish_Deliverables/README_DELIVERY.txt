KS PREDICTIVE JYOTISH — ALL DELIVERABLES (PRIVATE)

Contents:
- android/: signed 1.0.0 RELEASE APK
- source/: AGPL corresponding source archive (does not contain signing secrets)
- checksums/: SHA-256 checksums for APK and source archive
- reports/: build manifest, QA report, dependency/license report, APK inspection
- docs/: implementation status and build/readme instructions
- licenses/: AGPL and third-party notices
- signing/: private Android keystore and password/certificate details

SECURITY: This ZIP contains a private release keystore and its password. Store it securely, restrict access, and never publish it or send it with the public APK. The APK was signed with this key because no user-owned signing key was supplied. Preserve the keystore for future app updates or replace it with the product owner's permanent signing key before distribution.

The APK is signed but was not installed on an Android device in the build sandbox. Predictive validation remains INSUFFICIENT_DATA; see reports/TEST_REPORT.md and docs/BUILD_STATUS.md.
