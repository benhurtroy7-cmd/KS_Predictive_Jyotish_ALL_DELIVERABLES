# Build status — KS Predictive Jyotish 1.0.0

## Delivered

- Signed Android `release` variant APK, not a debug APK or Android UI prototype.
- Real Swiss Ephemeris 2.10.03 Moshier calculations compiled through JNI; no mock/fallback planetary positions and no external ephemeris files.
- Target API 35, min API 24; ABIs arm64-v8a and x86_64.
- Encrypted multi-profile local storage; chart, cusp, KP subdivision, dasha, transit, evidence, diagnostics, and research-lab views.
- Optional FastAPI `/health`, `/chart`, `/query` reference API; loopback-only by default; public serving requires TLS and bearer token.
- Source archive includes the corresponding app/JNI and Swiss Ephemeris source under AGPL-3.0-only.

## QA performed

1. Original embedded Python foundation was reconstructed, then extended. Current Python suite: **15 passed**. Coverage run: **86%** over `ks_engine` (710 statements). One non-failing Starlette `TestClient` deprecation warning was emitted.
2. API smoke tests passed for `/health`, `/chart`, and `/query`.
3. Native JNI C entry point was host-JVM smoke tested against the pinned Swiss Ephemeris 2.10.03 Moshier reference fixture. 29 numerical outputs matched at max absolute delta **0.0** in the host fixture run. Also exercised 25 ayanamsa/house combinations and geometric/topocentric flags.
4. Clean Gradle `:app:assembleRelease` and `:app:lintVitalRelease` passed. Release APK signature verified with APK Signature Scheme v2. Manifest target SDK 35, `allowBackup=false`, cleartext disabled, and no requested permissions.
5. APK contains arm64-v8a and x86_64 native libraries. No `.se1`/JPL data files are included.

## QA not performed / limitations

- No Android emulator/physical-device installation smoke was possible in the sandbox: the Android Emulator required more guest RAM than the environment's 2 GB limit. Android packaging, signature, manifest, native ABI, and the same JNI function on a host JVM were checked instead. Install and UI verification on a real device remain outstanding.
- The reference fixture and JNI implementation use the same Swiss Ephemeris/Moshier implementation/version; this is a regression check, **not** an independent astronomy-backend comparison. LibEphemeris was not installed, so no second-backend comparison was available.
- This release calculates charts and exposes deterministic evidence, but does not have complete KP New/KP Swiss/Parashari predictive rule coverage, full CSL/significator doctrine, event-date prediction generation, blind retrodiction, walk-forward validation, or independent calibration. The correct displayed state is `EVIDENCE_ONLY` / `INSUFFICIENT_DATA`. Do not represent it as a validated predictive product or advertise predictive accuracy.
- Historical events use local-noon transit features when only an event date is provided; that is tagged as a date-only proxy, not an event moment. Discovered patterns stay `DISCOVERED` and are not used to forecast.
- The Python JSON API is a tested optional reference service, not a deployed cloud backend and not integrated into the Android app. The Android app is offline/local-only.
- No user-provided release signing key was attached. The APK is signed with a newly generated self-signed local key. It is built as a signed Android release APK; installation on a physical Android device was not runtime-verified in this sandbox. Store identity/update continuity requires the product owner's permanent signing key and final package ID decision.
