# KS Predictive Jyotish — Android Release 1.0.0

A native Android build plus a deterministic Python reference/API package reconstructed from the supplied MASTER BUILD file. The shipped Android app performs real on-device calculations through Swiss Ephemeris 2.10.03 and its built-in Moshier model. It includes no proprietary `.se1` or JPL ephemeris files and makes no network or localhost call.

## Release artifact

- `../KS_Predictive_Jyotish_1.0.0_RELEASE.apk` — signed Android release APK (arm64-v8a and x86_64; min API 24, target API 35).
- `reports/BUILD_MANIFEST.json`, `reports/TEST_REPORT.md`, and `reports/DEPENDENCY_LICENSE_REPORT.md` — build identity, QA, dependency/license status, and known limitations.
- The release uses a locally generated self-signed key because no user/Play signing key was supplied. Key continuity details are in `../KS_Release_Signing_Info.txt`. Do not publish the included private key; replace it with the product owner's permanent key before store distribution.

## Implemented in the Android app

- Multiple locally stored birth profiles, including seconds, IANA timezone, explicit UTC offset for DST overlaps, latitude, longitude, and optional altitude.
- AES-256-GCM encrypted local storage backed by Android Keystore; Android backup is disabled.
- Swiss Ephemeris JNI backend, explicitly selecting built-in Moshier calculations; no mocked chart or offline fallback.
- Lahiri, KP, KP New (VP291), Fagan–Bradley, and Raman ayanamsas; Placidus, Koch, Equal, Whole Sign, and Porphyry houses; geocentric/topocentric and apparent/geometric calculation modes.
- Sun through Saturn, true Rahu and opposite Ketu; twelve cusps; KP star/sub/sub-sub subdivisions; Vimshottari Maha/Antar/Pratyantar timing; current transits.
- Free-text deterministic question routing, versioned rule evidence, a “Why this prediction?” evidence trail, and explicit `EVIDENCE_ONLY` / `INSUFFICIENT_DATA` states.
- Prediction Laboratory with date-only historical feature extraction (local-noon proxy, explicitly labelled), `DISCOVERED` patterns, hash-chained user-entered hypotheses/outcomes, and descriptive report counts.
- Beginner / Professional display modes, diagnostics, and in-app notices.

## Integrity and current product boundary

The app does **not** claim predictive accuracy. It will not invent a future event date, probability, or confidence interval. The four methodology labels (KP, KP New, KP Swiss, Parashari) are exposed, but the rule layer currently provides limited, versioned chart evidence; it does not implement complete KP CSL/4-step ownership/aspect doctrine or a complete Parashari predictive engine. Historical feature groupings remain `DISCOVERED`; no pattern is promoted to `VALIDATED`. User-entered timing windows are not forecasts from the engine.

The optional FastAPI `/health`, `/chart`, and `/query` contract is tested, but it is not deployed as a cloud service or integrated into the APK. The APK is local/private only. A public API bind requires TLS certificate/key plus `KS_API_TOKEN`.

## Build the Android release

Prerequisites: JDK 17+, Android SDK platform/build-tools 35, NDK 27.2.12479018, CMake 3.22.1, and Gradle 8.9 (wrapper included).

The reproducible native build is wired through `app/src/main/cpp/CMakeLists.txt`; the Swiss Ephemeris source at tag `v2.10.03` is under `third_party/swisseph/`.

```bash
export ANDROID_SDK_ROOT="$HOME/Android/Sdk"
export KS_STORE_PASSWORD='your-keystore-password'
export KS_KEY_ALIAS='your-alias'
./gradlew clean :app:assembleRelease :app:lintVitalRelease
```

Supply a permanent user-controlled release keystore at `release-signing/ks-release.keystore` or update `app/build.gradle` for your key. Never commit signing passwords or a production private key. The local build signing credentials supplied with this workspace are for this generated APK only.

## Python reference core / JSON API

```bash
python -m pip install -r requirements-dev.txt
pytest --cov=ks_engine --cov-report=term-missing -q
python run_server.py                    # loopback-only developer API
```

`run_server.py` refuses a non-loopback bind unless `--tls-cert`, `--tls-key`, and `KS_API_TOKEN` are provided. The API returns `UNVERIFIED` if its astronomy runtime cannot be loaded; it never substitutes mock positions.

## Licensing

The combined distributed Android application is provided under AGPL-3.0-only for the selected Swiss Ephemeris component; no Swiss Ephemeris professional license is claimed. The original standalone Python core's MIT notice is retained in `MIT-LICENSE-CORE.txt`. See `LICENSE`, `LICENSE-AGPL-3.0.txt`, `NOTICE.md`, and the in-app notices.
