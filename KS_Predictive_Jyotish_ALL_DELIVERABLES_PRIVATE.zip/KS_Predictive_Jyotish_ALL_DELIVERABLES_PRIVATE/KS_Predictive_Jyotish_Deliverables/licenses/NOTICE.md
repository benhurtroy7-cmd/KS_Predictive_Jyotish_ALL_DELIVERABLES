# Third-party notices and licensing BOM summary

## Distributed Android release

The APK includes Swiss Ephemeris C source 2.10.03 from the Astrodienst public repository tag `v2.10.03`, built as a JNI library. This release uses the built-in Moshier model with `SEFLG_MOSEPH`; it bundles **no** Swiss `.se1` ephemeris files, JPL DE files, or other proprietary astronomy data. The Swiss Ephemeris license requires a choice between AGPL and a professional license. This distribution selects **AGPL-3.0-only**; no professional license is claimed. The full license and corresponding source are included in this source package and in the app's `assets/licenses/` directory.

Swiss Ephemeris licensing requires the combined program to be AGPL or a compatible license unless a separate professional license is obtained. The Android app sources and JNI glue in this package are consequently distributed under AGPL-3.0-only. The upstream notices in `third_party/swisseph/LICENSE` remain intact.

## Python API/reference package

- `pyswisseph==2.10.3.2`: Swiss Ephemeris Python binding, AGPL/professional dual-license terms upstream; this environment/package selects AGPL-compatible use.
- `fastapi`: MIT.
- `pydantic`: MIT.
- `uvicorn`: BSD-3-Clause.
- `starlette`: BSD-3-Clause.
- Test-only `pytest`: MIT; `httpx`: BSD-3-Clause; `pytest-cov`/`coverage`: Apache-2.0.

Exact Python package pins and optional developer-test dependencies are listed in `requirements.txt` and `requirements-dev.txt`. `requirements-libephemeris.txt` is an optional alternative only; LibEphemeris 3.x is AGPL-3.0-only and is not packaged into the Android APK.

## Android build toolchain

The APK is built against Android API 35 with Android Gradle Plugin 8.7.3, Gradle 8.9, NDK 27.2.12479018, and CMake 3.22.1. The Android runtime has no Maven/AndroidX dependency; calculations and UI use platform APIs plus the included native library. The build toolchain is not redistributed in the APK.

## App/source notices

- The original standalone Python core provided by the user had an MIT notice. It is preserved in `MIT-LICENSE-CORE.txt`.
- The complete AGPL-3.0 text is in `LICENSE-AGPL-3.0.txt`.
- The APK does not request INTERNET or location permission. The optional API is developer-operated; for non-loopback deployment, `run_server.py` requires TLS and a bearer token.
