# Dependency / license report

**Distribution:** Android APK and corresponding source. License review is a technical inventory, not legal advice.

## Android runtime

| Component | Version | Runtime/bundle use | License / notice |
|---|---:|---|---|
| Swiss Ephemeris C library | 2.10.03 (`v2.10.03`) | Native JNI calculation engine; explicit built-in Moshier model | AGPL-3.0-only selected for this distribution. Upstream `third_party/swisseph/LICENSE` preserved; full AGPL in `LICENSE-AGPL-3.0.txt` and APK assets. Corresponding source included in source archive. |
| Moshier ephemeris model | Included in Swiss Ephemeris source | Real analytical astronomy model | Covered by selected Swiss Ephemeris source/license terms. No external `.se1`, JPL DE, or other proprietary data files bundled. |
| Android platform APIs | API 24+ / target 35 | UI, local storage, Keystore crypto, JSON | Android platform; not a bundled runtime library. |
| Android Gradle Plugin | 8.7.3 | Build time only | Google Android build tooling terms; not shipped as a runtime library. |
| Gradle | 8.9 | Build time only | Apache-2.0; wrapper included. |
| Android NDK | 27.2.12479018 | Build time; C JNI library compilation | Android NDK license; not shipped as a runtime SDK. |
| CMake | 3.22.1 | Build time | CMake license; not shipped as a runtime library. |

The app has no AndroidX/Maven runtime dependencies. Manifest inspection found no `INTERNET`, location, or other requested permission. Local profile/research data is encrypted with AES-256-GCM using Android Keystore; Android backup is disabled.

## Optional Python API/reference runtime

| Package | Version constraint | License (upstream) | Notes |
|---|---|---|---|
| FastAPI | `>=0.115,<1` | MIT | Optional `/health`, `/chart`, `/query` service |
| Uvicorn | `>=0.34,<1` | BSD-3-Clause | Optional server; loopback-only by default |
| Pydantic | `>=2.8,<3` | MIT | API validation |
| Starlette | FastAPI transitive | BSD-3-Clause | API framework runtime |
| pyswisseph | `==2.10.3.2` | Swiss Ephemeris AGPL/professional dual license upstream | Explicit Moshier mode; no ephemeris data included |
| pytest | dev only | MIT | Test runner |
| pytest-cov / coverage | dev only | Apache-2.0 | Coverage measurement |
| httpx | dev/test only | BSD-3-Clause | FastAPI TestClient dependency |

`requirements-libephemeris.txt` describes an alternative adapter dependency (`libephemeris==3.0.0`), which is **not** installed into this APK and is not used by the release. Its upstream license is AGPL-3.0-only; a future deployment using it must comply and provide corresponding source/notices.

## Distribution obligations / signing

- This APK contains an AGPL-licensed component and is distributed with the corresponding source in `KS_Predictive_Jyotish_Source_AGPL.zip`.
- The APK is signed with a self-generated local Android release key because the request included no user-controlled key. Key information is supplied separately in `KS_Release_Signing_Info.txt`; treat both that file and the `.keystore` as secrets. A publisher must replace the key/package identity before adopting a permanent release pipeline.
- No Swiss Ephemeris professional license or proprietary ephemeris data rights are asserted.
- The API is not deployed; any public server operation needs valid TLS certificates and a strong bearer token. The Android app does not connect to it.
