# QA / test report

**Build:** KS Predictive Jyotish 1.0.0 · Android `release` variant · 2026-10-08

## Results

| Gate | Result | Notes |
|---|---|---|
| Python core unit tests | PASS | `pytest -q`: 15 passed |
| Python core line coverage | PASS | 86% total, 710 statements (`pytest --cov=ks_engine`) |
| JSON API smoke | PASS | TestClient exercised `GET /health`, `POST /chart`, `POST /query`; malformed input rejected |
| Reference chart regression | PASS | Chennai fixture `1971-01-22 18:30:00 Asia/Kolkata`, KP, Placidus, explicit Moshier |
| JNI/native fixture | PASS | Host-JVM invokes same JNI symbol; 29 values, max absolute delta 0.0 against pinned PySwissEph 2.10.03 fixture |
| Ayanamsa/house configuration smoke | PASS | 25 combinations: 5 supported sidereal modes × 5 house systems |
| Android ledger logic smoke | PASS | Host JVM tested append/freeze/outcome, hash verification, and tamper detection |
| Geometric/topocentric native smoke | PASS | Geometric mode changes apparent coordinates; topocentric Moon correction applied |
| Clean Android release build | PASS | `./gradlew clean :app:assembleRelease :app:lintVitalRelease` |
| Android lint vital | PASS | No release-blocking lint error |
| APK signature | PASS | APK Signature Scheme v2; one signer; RSA 4096 |
| APK target/ABI/permission inspection | PASS | Target 35, min 24; arm64-v8a and x86_64; no requested runtime permissions |
| Device install / app UI smoke | NOT RUN | Emulator launch failed because the sandbox's 2 GB RAM limit was below emulator requirements; no physical device was attached |
| Independent second astronomy backend comparison | NOT RUN | LibEphemeris was not installed. PySwissEph and Android JNI use the same Swiss Ephemeris release/Moshier model, so the fixture check is not an independent comparison |
| Blind prediction / out-of-sample validation | NOT AVAILABLE | No preregistered predictive model or independent outcome dataset exists; app stays EVIDENCE_ONLY / INSUFFICIENT_DATA |

## Reference fixture

Fixture file: `tests/fixtures/chennai_1971_kp_moshier.json`.
The fixture was generated from Swiss Ephemeris 2.10.03 using explicit Moshier flags, KP ayanamsa, Placidus cusps, and the local time converted to `13:00:00 UTC`. Tolerance is `1e-7` degrees. This is a deterministic regression fixture from the same astronomy engine, not an independent truth benchmark.

## Native harness

`tests/NativeChartSmoke.java` was compiled/run on the host JVM against a host build of the JNI C function and the same pinned Swiss Ephemeris sources. It exercises the exact JNI symbol and fixed result layout used by the app; all five ayanamsa mappings and five house systems were checked, plus geometric and topocentric calculation flags. Android ABI binaries themselves were produced by the Gradle/NDK CMake build and inspected in the APK; emulator execution was blocked by memory.

## Known warning

The Python API test client reports a non-failing Starlette deprecation warning about its `httpx` compatibility path. All tests pass. It is not a release-blocking Android warning.
