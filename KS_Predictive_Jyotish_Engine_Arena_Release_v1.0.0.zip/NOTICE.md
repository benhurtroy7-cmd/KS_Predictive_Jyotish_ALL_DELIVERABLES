# Third-party notices

This repository does not bundle third-party ephemeris binaries or data.

## Swiss Ephemeris / pyswisseph
Used only as an optional validation/runtime adapter. Review the upstream license before commercial distribution.

## LibEphemeris
Optional adapter only. Current upstream release 3.0.0 is AGPL-3.0-only. If this dependency is used in a networked commercial deployment, publish corresponding source and notices as required by AGPL.

## Astronomy data
Do not copy proprietary ephemeris files into this repository unless their license permits redistribution.
