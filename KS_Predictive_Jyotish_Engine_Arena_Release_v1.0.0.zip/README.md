# KS Predictive Jyotish Engine

Production-oriented foundation for the KS astrology product.

## Non-negotiable integrity rules
- No simulated astronomical values.
- No invented prediction dates.
- Astronomy must come from an injected verified backend.
- Discovered historical patterns are not automatically valid.
- Predictions are frozen before outcomes are known.
- Statistical probability is not claimed until genuine calibration data exists.

## Current implementation
- Birth-data validation
- Deterministic KP nakshatra/pada/sub-lord subdivision calculation
- Free-text query classification
- Historical pattern data structures and matching framework
- Immutable prediction ledger and outcome scoring
- Astronomy backend injection boundary

## Next implementation layers
1. Actual Swiss/LibEphemeris adapters using the installed target runtime.
2. Full chart/cusp calculation.
3. Dasha engine.
4. KP significator/CSL/4-step rule engine.
5. Parashari module.
6. Transit scanner.
7. Historical feature extraction.
8. Blind walk-forward validation.
9. Android/API integration.

The repository intentionally does not fabricate an astronomy result when a runtime is unavailable.
