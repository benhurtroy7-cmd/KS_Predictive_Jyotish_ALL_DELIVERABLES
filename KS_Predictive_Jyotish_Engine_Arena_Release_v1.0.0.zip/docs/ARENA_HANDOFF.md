# ARENA BUILD INSTRUCTION — KS Predictive Jyotish Engine v1.0.0

Build a **production RELEASE Android APK**, not a prototype and not a debug APK.

## Source
Use the complete attached ZIP/repository as the deterministic core. Do not rewrite or replace the engine with mock data.

## Required product
Android app with:
- Profile/birth-chart management: name, date, time including seconds, IANA timezone, latitude, longitude, altitude.
- Multiple profiles/charts.
- Free-text query input.
- Real chart calculation through the configured astronomy service.
- KP-style nakshatra/star/sub-lord calculations, Vimshottari dasha, explicit rule IDs, evidence output.
- Traditional/Parashari module architecture ready for expansion; never display fabricated results.
- Prediction Laboratory with historical event records, frozen predictions, outcomes, walk-forward/backtest reports, calibration metrics and PASS/FAIL status.
- “Why this prediction?” evidence screen.
- Short user-facing results plus professional/audit detail.
- Local/private calculation mode where the selected licensed backend permits it; cloud/hybrid API mode.
- JSON API contract matching /health, /chart and /query in the package.

## Astronomy requirements
Do not hardcode planetary positions. Use a real installed astronomy backend. The source contains adapters for pyswisseph and LibEphemeris. The selected production backend MUST be licensed for the distribution model. If LibEphemeris 3.0.0 is used, comply with AGPL-3.0-only; do not hide or bypass its obligations.

## Accuracy and claims
Never claim a prediction is accurate merely because a calculation succeeds. Never invent probability, confidence intervals, historical events, or validation scores. Probability is allowed only after blind/out-of-sample calibration data supports it. Display UNVERIFIED/INSUFFICIENT_DATA where appropriate.

## Android implementation
- Release build only.
- No Termux dependency for ordinary users.
- No localhost transport dependency in the final consumer app unless explicitly configured as developer mode.
- No dangerous permission should be required for normal operation.
- Network traffic must use HTTPS in production.
- Store user profiles securely.
- Offline mode must never silently substitute fake astronomy.
- Include a diagnostics screen showing backend, ephemeris, ayanamsa, house system, calculation timestamp, validation state and app version.

## Required QA before producing APK
1. Unit tests pass.
2. API smoke tests pass.
3. Real chart test with known reference fixture passes within documented tolerances.
4. Cross-backend comparison report generated when two backends are available.
5. No mocked planetary data in production path.
6. Prediction Laboratory clearly distinguishes DISCOVERED, UNDER_TEST, VALIDATED, REJECTED and INSUFFICIENT_DATA.
7. Release APK is signed with the Arena/user-provided release key and is installable on Android.
8. Provide APK plus SHA-256 and build manifest.

## Do not do
- Do not downgrade this to a demo.
- Do not use an LLM to calculate planets, houses, dashas or rule outcomes.
- Do not replace deterministic modules with generated prose.
- Do not add proprietary ephemeris files without licensing.
- Do not claim 99.9% accuracy or any unvalidated accuracy percentage.
