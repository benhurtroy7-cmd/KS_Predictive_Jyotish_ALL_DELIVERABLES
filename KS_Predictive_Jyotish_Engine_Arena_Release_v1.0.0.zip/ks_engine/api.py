from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from dataclasses import asdict
from .models import BirthData
from .astro import SwissEphemerisBackend
from .engine import Engine
app=FastAPI(title='KS Predictive Jyotish Engine',version='1.0.0')
backend=SwissEphemerisBackend(); engine=Engine(backend)
class BirthIn(BaseModel):
 name:str='Profile'; local_datetime:str; timezone:str; latitude:float=Field(ge=-90,le=90); longitude:float=Field(ge=-180,le=180); altitude_m:float=0
class QueryIn(BaseModel): birth:BirthIn; question:str
@app.get('/health')
def health(): return {'status':'ok','engine':'ks-predictive-jyotish','astronomy':'pyswisseph','calculation':'real'}
@app.post('/chart')
def chart(x:BirthIn):
 try: return asdict(engine.chart(BirthData(**x.model_dump())))
 except Exception as e: raise HTTPException(400,str(e))
@app.post('/query')
def query(x:QueryIn):
 try:
  r=engine.answer(BirthData(**x.birth.model_dump()),x.question)
  if hasattr(r.get('chart'),'meta'): r['chart']=asdict(r['chart'])
  return r
 except Exception as e: raise HTTPException(400,str(e))
