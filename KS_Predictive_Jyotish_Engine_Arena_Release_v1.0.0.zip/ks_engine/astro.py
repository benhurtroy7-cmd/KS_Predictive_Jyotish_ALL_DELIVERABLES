from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import math
from .models import *
from .kp import enrich

PLANETS = [('Sun',0),('Moon',1),('Mars',4),('Mercury',2),('Jupiter',5),('Venus',3),('Saturn',6),('Rahu',10),('Ketu',11)]
SIGNS = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
AYAN = {'lahiri':1,'kp':1,'fagan_bradley':0}

class SwissEphemerisBackend:
    """Real pyswisseph adapter. Optional dependency; never fabricates astronomy."""
    def __init__(self, ayanamsa='lahiri', house_system='P', sidereal=True):
        import swisseph as swe
        self.swe=swe; self.ayanamsa=ayanamsa.lower(); self.house_system=house_system; self.sidereal=sidereal
    def _jd(self,b):
        dt=datetime.fromisoformat(b.local_datetime).replace(tzinfo=ZoneInfo(b.timezone))
        u=dt.astimezone(timezone.utc)
        return self.swe.julday(u.year,u.month,u.day,u.hour+u.minute/60+u.second/3600+u.microsecond/3.6e9)
    def calculate(self,birth):
        swe=self.swe; jd=self._jd(birth)
        if self.sidereal:
            mode = swe.SIDM_LAHIRI if self.ayanamsa in ('lahiri','kp') else swe.SIDM_FAGAN_BRADLEY
            swe.set_sid_mode(mode)
            flags=swe.FLG_SWIEPH|swe.FLG_SPEED|swe.FLG_SIDEREAL
        else: flags=swe.FLG_SWIEPH|swe.FLG_SPEED
        ps=[]
        for name,p in PLANETS:
            x,rf=swe.calc_ut(jd,p,flags); lon=x[0]%360
            e=enrich(lon)
            ps.append(PlanetPosition(name,lon,x[3],x[3]<0,int(lon//30),e['nakshatra_index'],e['pada'],e['star_lord'],e['sub_lord'],None))
        cusps, angles=swe.houses_ex(jd,birth.latitude,birth.longitude,self.house_system.encode(), flags if self.sidereal else 0)
        asc=angles[0]%360
        return ChartResult(CalculationMeta('pyswisseph', 'Swiss Ephemeris', self.ayanamsa, self.house_system,jd,True),ps,asc,[c%360 for c in cusps],[])

class LibEphemerisBackend:
    """Adapter loaded only when libephemeris is installed in the target environment."""
    def __init__(self, **kwargs):
        import libephemeris as swe
        self.swe=swe; self.kwargs=kwargs
    def calculate(self,birth):
        # API-compatible core calculation; house/ayanamsa details are delegated to libephemeris.
        swe=self.swe
        dt=datetime.fromisoformat(birth.local_datetime).replace(tzinfo=ZoneInfo(birth.timezone)).astimezone(timezone.utc)
        jd=swe.julday(dt.year,dt.month,dt.day,dt.hour+dt.minute/60+dt.second/3600)
        flags=swe.FLG_SWIEPH|swe.FLG_SPEED
        ps=[]
        for name,p in PLANETS:
            x,_=swe.calc_ut(jd,p,flags); lon=x[0]%360; e=enrich(lon)
            ps.append(PlanetPosition(name,lon,x[3],x[3]<0,int(lon//30),e['nakshatra_index'],e['pada'],e['star_lord'],e['sub_lord'],None))
        return ChartResult(CalculationMeta('libephemeris','LibEphemeris',self.kwargs.get('ayanamsa','lahiri'),'P',jd,True),ps,None,[],['House calculation must use the configured LibEphemeris house API in the deployment adapter.'])
