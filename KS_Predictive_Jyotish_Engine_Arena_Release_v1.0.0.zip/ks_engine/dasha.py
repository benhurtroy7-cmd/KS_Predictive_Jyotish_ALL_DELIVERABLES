from datetime import datetime, timedelta
from .kp import DASHA_YEARS, ORDER, NAKSHATRA_SPAN

def vimshottari_start(moon_longitude, birth_dt):
    idx=int((moon_longitude%360)/NAKSHATRA_SPAN); lord=ORDER[idx%9]
    within=(moon_longitude%360)-idx*NAKSHATRA_SPAN
    fraction=within/NAKSHATRA_SPAN
    elapsed=DASHA_YEARS[lord]*fraction
    start=birth_dt-timedelta(days=elapsed*365.2425)
    return lord,start

def sequence_from(lord):
    i=ORDER.index(lord)
    return [ORDER[(i+j)%9] for j in range(9)]

def periods(moon_longitude,birth_dt,years=120):
    lord,start=vimshottari_start(moon_longitude,birth_dt); out=[]; cur=start
    # include from dasha beginning through 120 years
    for l in sequence_from(lord):
        end=cur+timedelta(days=DASHA_YEARS[l]*365.2425)
        out.append({'lord':l,'start':cur.isoformat(),'end':end.isoformat()})
        cur=end
    return out
