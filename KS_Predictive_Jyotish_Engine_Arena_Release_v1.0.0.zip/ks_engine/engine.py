from .query import classify
from .dasha import periods
from .rules import evidence
class Engine:
    def __init__(self, astronomy_backend=None): self.astronomy=astronomy_backend
    def chart(self,birth):
        birth.validate()
        if self.astronomy is None: return {'status':'UNVERIFIED','error':'ASTRONOMY_BACKEND_UNAVAILABLE'}
        return self.astronomy.calculate(birth)
    def answer(self,birth,question):
        parsed=classify(question)
        if not parsed['resolved']: return {'status':'UNRESOLVED','reason':'No defensible deterministic domain mapping','query':parsed}
        chart=self.chart(birth)
        if not hasattr(chart,'planets'): return {'status':'UNVERIFIED','query':parsed,'chart':chart}
        moon=next((p.longitude for p in chart.planets if p.name=='Moon'),None)
        from datetime import datetime
        from zoneinfo import ZoneInfo
        dt=datetime.fromisoformat(birth.local_datetime).replace(tzinfo=ZoneInfo(birth.timezone))
        ds=periods(moon,dt) if moon is not None else []
        ev=evidence(chart,parsed['domain'])
        return {'status':'CALCULATED','query':parsed,'chart':chart,'evidence':ev,'vimshottari':ds,'prediction':{'state':'EVIDENCE_ONLY','message':'Validated predictive calibration is not yet claimed; review evidence and run Prediction Laboratory backtests.'}}
