"""Deterministic KP subdivision utilities.

The KP unequal sub-lord boundaries are derived from Vimshottari proportions;
no hand-coded sub-lord lookup table is used.
"""

DASHA_YEARS = {
    'Ketu': 7, 'Venus': 20, 'Sun': 6, 'Moon': 10, 'Mars': 7,
    'Rahu': 18, 'Jupiter': 16, 'Saturn': 19, 'Mercury': 17,
}
ORDER = list(DASHA_YEARS)
NAKSHATRA_SPAN = 13 + 20/60
TOTAL_YEARS = 120


def normalize_deg(x: float) -> float:
    return x % 360.0


def nakshatra_index(longitude: float) -> int:
    return int(normalize_deg(longitude) / NAKSHATRA_SPAN)


def pada(longitude: float) -> int:
    within = normalize_deg(longitude) % NAKSHATRA_SPAN
    return int(within / (NAKSHATRA_SPAN / 4)) + 1


def star_lord(longitude: float) -> str:
    return ORDER[nakshatra_index(longitude) % 9]


def sub_lord(longitude: float):
    """Return sub-lord plus exact arc boundaries within the nakshatra."""
    lon = normalize_deg(longitude)
    ni = nakshatra_index(lon)
    start = ni * NAKSHATRA_SPAN
    within = lon - start
    first = ORDER[ni % 9]
    first_i = ORDER.index(first)
    cursor = 0.0
    segments = []
    for offset in range(9):
        lord = ORDER[(first_i + offset) % 9]
        span = NAKSHATRA_SPAN * DASHA_YEARS[lord] / TOTAL_YEARS
        segments.append((cursor, cursor + span, lord))
        cursor += span
    for a, b, lord in segments:
        if within < b or abs(within-b) < 1e-12:
            return {
                'nakshatra_index': ni,
                'nakshatra_start': start,
                'nakshatra_end': start + NAKSHATRA_SPAN,
                'star_lord': first,
                'sub_lord': lord,
                'sub_start': start + a,
                'sub_end': start + b,
                'distance_to_nearest_sub_boundary': min(abs(within-a), abs(b-within)),
            }
    raise AssertionError('KP subdivision construction failed')


def enrich(longitude: float) -> dict:
    s = sub_lord(longitude)
    s['pada'] = pada(longitude)
    return s
