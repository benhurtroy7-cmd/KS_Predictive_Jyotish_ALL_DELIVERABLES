from dataclasses import dataclass, field
from datetime import datetime, date
from typing import Optional, List, Dict, Any

@dataclass(frozen=True)
class BirthData:
    name: str
    local_datetime: str
    timezone: str
    latitude: float
    longitude: float
    altitude_m: float = 0.0

    def validate(self):
        if not (-90 <= self.latitude <= 90): raise ValueError('latitude must be -90..90')
        if not (-180 <= self.longitude <= 180): raise ValueError('longitude must be -180..180')
        dt = datetime.fromisoformat(self.local_datetime)
        if dt.tzinfo is not None: raise ValueError('local_datetime must not contain an offset; timezone is separate')

@dataclass(frozen=True)
class PlanetPosition:
    name: str
    longitude: float
    speed: Optional[float] = None
    retrograde: Optional[bool] = None
    sign: Optional[int] = None
    nakshatra: Optional[int] = None
    pada: Optional[int] = None
    star_lord: Optional[str] = None
    sub_lord: Optional[str] = None
    sub_sub_lord: Optional[str] = None

@dataclass(frozen=True)
class CalculationMeta:
    backend: str
    ephemeris: str
    ayanamsa: str
    house_system: str
    jd_ut: Optional[float]
    verified: bool

@dataclass
class ChartResult:
    meta: CalculationMeta
    planets: List[PlanetPosition] = field(default_factory=list)
    ascendant: Optional[float] = None
    cusps: List[float] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

@dataclass(frozen=True)
class HistoricalEvent:
    event_id: str
    profile: str
    category: str
    event_date: date
    description: str = ''
    certainty: str = 'known'

@dataclass
class PatternRecord:
    pattern_id: str
    category: str
    feature_counts: Dict[str, int]
    occurrences: int
    successes: int = 0
    failures: int = 0
    validation_status: str = 'DISCOVERED'
    source_event_ids: List[str] = field(default_factory=list)

@dataclass
class PredictionRecord:
    prediction_id: str
    created_at: str
    profile: str
    query: str
    category: str
    window_start: Optional[str]
    window_end: Optional[str]
    status: str
    score: Optional[float]
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    pattern_matches: List[Dict[str, Any]] = field(default_factory=list)
