from collections import Counter
from .models import HistoricalEvent, PatternRecord

class HistoricalPatternEngine:
    """Pattern extraction/matching only. It never treats discovered patterns as validated automatically."""
    def discover(self, rows):
        groups = {}
        for row in rows:
            key = (row['category'], tuple(sorted(row.get('features', []))))
            groups.setdefault(key, []).append(row)
        out = []
        for i, ((cat, feats), members) in enumerate(groups.items(), 1):
            out.append(PatternRecord(
                pattern_id=f'P{i:05d}', category=cat,
                feature_counts=dict(Counter(feats)), occurrences=len(members),
                source_event_ids=[m['event_id'] for m in members],
                validation_status='DISCOVERED'))
        return out

    def match(self, category, features, validated_only=True):
        candidates = []
        f = set(features)
        for p in getattr(self, 'patterns', []):
            if p.category != category: continue
            if validated_only and p.validation_status != 'VALIDATED': continue
            pf = set(p.feature_counts)
            union = len(f | pf)
            score = len(f & pf) / union if union else 0.0
            if score > 0: candidates.append((score, p))
        return sorted(candidates, key=lambda x: x[0], reverse=True)
