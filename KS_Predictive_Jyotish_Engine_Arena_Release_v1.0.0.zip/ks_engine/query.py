import re

DOMAINS = {
    'marriage': [r'\bmarriage\b', r'\bmarry\b', r'\bwedding\b', r'\bspouse\b'],
    'relationship': [r'\brelationship\b', r'\bpartner\b', r'\bdivorce\b', r'\bseparation\b'],
    'career': [r'\bcareer\b', r'\bjob\b', r'\bpromotion\b', r'\bemployment\b', r'\bbusiness\b'],
    'property': [r'\bproperty\b', r'\bhouse\b', r'\bhome\b', r'\bland\b', r'\bflat\b'],
    'finance': [r'\bmoney\b', r'\bincome\b', r'\bwealth\b', r'\bfinancial\b'],
    'travel': [r'\btravel\b', r'\bforeign\b', r'\boverseas\b', r'\bsettle abroad\b'],
    'education': [r'\beducation\b', r'\bexam\b', r'\bstudy\b', r'\bcollege\b'],
}

EVENT_TERMS = {
    'promotion': [r'\bpromotion\b'],
    'job_change': [r'\bchange jobs?\b', r'\bnew job\b'],
    'marriage': [r'\bmarriage\b', r'\bmarry\b', r'\bwedding\b'],
    'divorce': [r'\bdivorce\b', r'\bseparation\b'],
    'property_acquisition': [r'\bbuy\b.*\b(property|house|home|flat)\b', r'\bpurchase\b.*\b(property|house|home|flat)\b'],
}

def classify(question: str) -> dict:
    q = question.strip().lower()
    domain = None
    event = None
    for d, pats in DOMAINS.items():
        if any(re.search(p, q) for p in pats): domain = d; break
    for e, pats in EVENT_TERMS.items():
        if any(re.search(p, q) for p in pats): event = e; break
    years = sorted({int(y) for y in re.findall(r'\b(19\d{2}|20\d{2}|21\d{2})\b', q)})
    return {'question': question, 'domain': domain, 'event': event, 'years': years,
            'resolved': domain is not None}
