"""Explicit, versioned deterministic rule registry. Rules are evidence generators, not truth claims."""
from dataclasses import dataclass
from .models import ChartResult

@dataclass(frozen=True)
class Rule:
    id:str; version:str; domain:str; description:str

RULES=[
 Rule('KP-CAR-001','1.0','career','Career significator evidence: 2,6,10,11 houses.'),
 Rule('KP-MAR-001','1.0','marriage','Marriage evidence: 2,7,11 houses; 1,6,10 may oppose.'),
 Rule('KP-PROP-001','1.0','property','Property evidence: 4,11 with 2/8/12 context.'),
 Rule('KP-FIN-001','1.0','finance','Finance evidence: 2,6,10,11 and affliction/support context.'),
 Rule('KP-TRV-001','1.0','travel','Travel/foreign evidence: 3,9,12 with context.'),
 Rule('PAR-EDU-001','1.0','education','Education evidence: 2,4,5,9 and Mercury/Jupiter context.'),
]

def house_for_lon(lon, cusps):
    if not cusps or len(cusps)!=12: return None
    for i,c in enumerate(cusps):
        nxt=cusps[(i+1)%12]
        x=lon
        if i==11: nxt+=360
        while x<c: x+=360
        if c<=x<nxt: return i+1
    return None

def evidence(chart,domain):
    # Conservative: only report calculable planetary/cusp evidence; no fabricated event probability.
    target={'career':{2,6,10,11},'marriage':{2,7,11},'property':{4,11},'finance':{2,6,10,11},'travel':{3,9,12},'education':{2,4,5,9}}.get(domain,set())
    rows=[]
    for p in chart.planets:
        h=house_for_lon(p.longitude,chart.cusps)
        if h in target: rows.append({'planet':p.name,'house':h,'star_lord':p.star_lord,'sub_lord':p.sub_lord})
    return rows
