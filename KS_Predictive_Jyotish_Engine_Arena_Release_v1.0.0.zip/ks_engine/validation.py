from dataclasses import dataclass
from datetime import date

@dataclass(frozen=True)
class FrozenPrediction:
    prediction_id: str
    event_category: str
    window_start: date
    window_end: date
    score: float
    created_at: str

class ValidationLedger:
    """Immutable prediction ledger. Historical outcomes cannot rewrite predictions."""
    def __init__(self): self.predictions = {}
    def freeze(self, prediction: FrozenPrediction):
        if prediction.prediction_id in self.predictions:
            raise ValueError('prediction already frozen')
        self.predictions[prediction.prediction_id] = prediction
    def score_outcome(self, prediction_id, outcome_date):
        p = self.predictions[prediction_id]
        if p.window_start <= outcome_date <= p.window_end: return 'PASS'
        delta = min(abs((outcome_date-p.window_start).days), abs((outcome_date-p.window_end).days))
        if delta <= 7: return 'TIMING_NEAR_MISS'
        return 'EVENT_MISS'
