import uvicorn
uvicorn.run('ks_engine.api:app',host='127.0.0.1',port=8765)
