from ks_engine.kp import sub_lord
from ks_engine.query import classify
from ks_engine.models import BirthData
from ks_engine.dasha import periods
from ks_engine.astro import SwissEphemerisBackend

def test_kp_subdivision(): assert sub_lord(0)['star_lord']=='Ketu'
def test_query(): assert classify('Will I get a promotion in 2027?')['domain']=='career'
def test_birth_validation(): BirthData('x','1971-01-22T18:30:00','Asia/Kolkata',13.08,80.27).validate()
def test_real_chart():
 b=BirthData('x','1971-01-22T18:30:00','Asia/Kolkata',13.08,80.27)
 c=SwissEphemerisBackend().calculate(b); assert c.meta.verified and len(c.planets)==9 and len(c.cusps)==12
 moon=next(p.longitude for p in c.planets if p.name=='Moon'); assert len(periods(moon,__import__('datetime').datetime.fromisoformat(b.local_datetime).replace(tzinfo=__import__('zoneinfo').ZoneInfo(b.timezone))))==9
